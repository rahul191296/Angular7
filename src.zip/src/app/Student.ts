export class Student{

    rollNo: string;
    firstName: string;
    lastName: string;
    age: number;

}
