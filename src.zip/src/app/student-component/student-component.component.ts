import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../Student';
import { StudentServiceService } from '../student-service.service';

@Component({
  selector: 'app-student-component',
  templateUrl: './student-component.component.html',
  styleUrls: ['./student-component.component.css']
})

export class StudentComponentComponent implements OnInit {

  students: Student[];

  constructor(private router: Router, private studentService: StudentServiceService) {

  }
  
  ngOnInit() {
    this.studentService.getStudents()
      .subscribe( data => {
        this.students = data;
      });
  };

  deleteUser(student: Student): void {
    this.studentService.removeStudent(student)
      .subscribe( data => {
        this.students = this.students.filter(stud => stud !== student);
      })
  };

}
