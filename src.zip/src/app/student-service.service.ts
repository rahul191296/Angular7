import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Student} from '../app/Student';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class StudentServiceService {

  constructor(private http:HttpClient) { }

 private studentgetUrl = 'http://localhost:8081/student/allstudents';
   //private studentUrl = '/api';

  private studentPersistUrl='http://localhost:8081/student/persiststudent';

  private studentRemoveUrl='http://localhost:8081/student/deletestudent'
  
  public getStudents() {
    return this.http.get<Student[]>(this.studentgetUrl);
  }

  public removeStudent(student) {
    return this.http.delete(this.studentRemoveUrl + "/"+ student.id);
  }

  public persistStudent(student) {
    return this.http.post<Student>(this.studentPersistUrl, student);
  }
}
