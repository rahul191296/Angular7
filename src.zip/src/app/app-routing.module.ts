import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentComponentComponent } from '../app/student-component/student-component.component';

  import { AddStudentComponent } from './add-student/add-student.component';


const routes: Routes = [
  { path: 'allstudents', component: StudentComponentComponent },
  { path: 'persiststudent', component: AddStudentComponent }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
